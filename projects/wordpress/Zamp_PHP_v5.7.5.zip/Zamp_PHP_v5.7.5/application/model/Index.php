<?php
/**
 * 	@version       $Revision: 16 $
 * 	@modifiedby    $LastChangedBy: phpmathan $
 * 	@lastmodified  $Date: 2010-03-16 19:39:31 +0530 (Tue, 16 Mar 2010) $
 */

class Index extends Zamp_Object {
	
}

/* END OF FILE */