<html>
<head>
<title>Welcome to Zamp PHP</title>

<style type="text/css">
{literal}
body {
 background-color: #fff;
 margin: 40px;
 font-family: Lucida Grande, Verdana, Sans-serif;
 font-size: 14px;
 color: #4F5155;
}

h1 {
 color: #444;
 background-color: transparent;
 border-bottom: 1px solid #D0D0D0;
 font-size: 16px;
 font-weight: bold;
 margin: 24px 0 2px 0;
 padding: 5px 0 6px 0;
}
{/literal}
</style>
</head>
<body>

<h1>Welcome to Zamp PHP!</h1>

<p>The page you are looking at is being generated dynamically by Zamp PHP.</p>

<p><br/>Page rendered in <?php echo $processing_time;?>.</p>

</body>
</html>